export const environment = {
  production: false,
  firebase: {
      apiKey: "AIzaSyD5s2Rkq1NwkXrs-Xjk9AVxP94bcWO6fe8",
    authDomain: "signuploginapp-e51b2.firebaseapp.com",
    databaseURL: "https://signuploginapp-e51b2-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "signuploginapp-e51b2",
    storageBucket: "signuploginapp-e51b2.firebasestorage.app",
    messagingSenderId: "578364808712",
    appId: "1:578364808712:web:45701c93a9302601c93bbd",
    measurementId: "G-ZXMYXSXB97"
  }
};
