import { Component } from '@angular/core';

@Component({
  selector: 'app-offboarding-report',
  templateUrl: './offboarding-report.component.html',
  styleUrl: './offboarding-report.component.scss'
})
export class OffboardingReportComponent {

}
