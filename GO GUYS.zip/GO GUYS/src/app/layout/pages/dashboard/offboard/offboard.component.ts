import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OffboardService } from '../../../../services/offboard.service';

@Component({
  selector: 'app-offboard',
  templateUrl: './offboard.component.html',
  styleUrls: ['./offboard.component.scss']
})
export class OffboardComponent implements OnInit {
  employeeId: string = '';
  employeeName: string = '';
  profileImageUrl: string = '';
  offboardForm: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private offboardService: OffboardService,
    private auth: AngularFireAuth
  ) {
    this.offboardForm = this.fb.group({
      effectiveDate: ['', Validators.required],
      personalEmail: ['', [Validators.required, Validators.email]],
      exitInterview: ['', Validators.required],
      automatedNotification: ['', Validators.required],
      clearanceFileUrl: [''],
      certificationFileUrl: ['']
    });
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.employeeId = params['id'] || ''; // Ensure the employeeId is passed
      this.employeeName = params['name'] || 'No Name Provided';
      this.profileImageUrl = params['profileImageUrl'] || 'picpro.jpg';
    });
  }

  handleFileUpload(event: any, fileType: 'clearance' | 'certification') {
    const file = event.target.files[0];
    if (file && this.employeeId) {
      this.offboardService.uploadFile(file, fileType, this.employeeId).subscribe(
        downloadUrl => {
          const control = fileType === 'clearance' ? 'clearanceFileUrl' : 'certificationFileUrl';
          this.offboardForm.patchValue({ [control]: downloadUrl });
          console.log(`${fileType} uploaded successfully:`, downloadUrl);
        },
        error => {
          console.error('Error uploading file:', error);
          alert(`Failed to upload ${fileType}. Please try again.`);
        }
      );
    } else {
      alert('Invalid file or missing employee ID.');
    }
  }

  submitForm() {
    if (this.offboardForm.valid) {
      this.auth.user.subscribe(user => {
        if (user && this.employeeId) {
          const formData = this.offboardForm.value;
          const offboardData = {
            name: this.employeeName,
            profileImageUrl: this.profileImageUrl,
            ...formData,
            submittedAt: new Date()
          };

          console.log('Submitting data:', offboardData);

          this.offboardService.saveOffboardingData(this.employeeId, offboardData)
            .then(() => {
              console.log('Data saved successfully');
              alert('Offboarding data saved successfully!');
              this.offboardForm.reset();
            })
            .catch(error => {
              console.error('Error saving data:', error);
              alert('Failed to save offboarding data. Please try again.');
            });
        } else {
          console.error('User not authenticated or missing employee ID');
          alert('You must be logged in to submit data.');
        }
      });
    } else {
      alert('Please fill in all required fields');
      console.log('Form invalid:', this.offboardForm.errors);
    }
  }
}
