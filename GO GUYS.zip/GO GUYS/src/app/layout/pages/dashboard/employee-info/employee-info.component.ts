import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../../../../models/employee.model';
import { EmployeesService } from '../../../../services/employees.service';

@Component({
  selector: 'app-employee-info',
  templateUrl: './employee-info.component.html',
  styleUrls: ['./employee-info.component.scss']
})
export class EmployeeInfoComponent implements OnInit {
  employees: Employee[] = [];
  filteredEmployees: Employee[] = [];
  searchQuery: string = '';
  selectedEmployee: Employee | null = null;

  constructor(
    private router: Router,
    private employeesService: EmployeesService
  ) {}

  ngOnInit() {
    this.employeesService.getEmployees().subscribe(data => {
      this.employees = data;
      this.filteredEmployees = [...this.employees];
    });
  }

  searchEmployee(query: string) {
    this.filteredEmployees = this.employees.filter(emp =>
      emp.name.toLowerCase().includes(query.toLowerCase())
    );
  }

  openModal(employee: Employee) {
    console.log("Opening modal for:", employee);
    this.selectedEmployee = employee;
  }

  closeModal() {
    this.selectedEmployee = null;
  }

  deleteEmployee() {
    if (this.selectedEmployee?.id) {
      this.employeesService.deleteEmployee(this.selectedEmployee.id);
      alert('Employee deleted successfully');
      this.closeModal();
    }
  }

  updateEmployee() {
    if (this.selectedEmployee?.id) {
      // Navigate to update form or implement update logic
      console.log('Update employee:', this.selectedEmployee);
    }
  }

  moveToOffboarding() {
    if (!this.selectedEmployee) {
      console.warn("No employee selected for offboarding.");
      return;
    }

    this.router.navigate(['/offboard'], {
      queryParams: {
        id: this.selectedEmployee.id, // Ensure the employee ID is passed
        name: this.selectedEmployee.name,
        profileImageUrl: this.selectedEmployee.profileImageUrl
      }
    });
  }

}
