import { Offboard } from './offboard.model';

describe('Offboard', () => {
  it('should create an instance', () => {
    expect(new Offboard()).toBeTruthy();
  });
});
