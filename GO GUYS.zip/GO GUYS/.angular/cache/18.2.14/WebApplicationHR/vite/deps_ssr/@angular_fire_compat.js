import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-2S6N7PRS.js";
import "./chunk-7DHJRVJV.js";
import "./chunk-JCK2OIYT.js";
import "./chunk-VFW7PX74.js";
import "./chunk-KKWATYV7.js";
import "./chunk-CTUJN5VU.js";
import "./chunk-LKDWXENB.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
