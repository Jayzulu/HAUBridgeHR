import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-GIKJLUUA.js";
import "./chunk-RSA4Y4B6.js";
import "./chunk-WLTG5KEO.js";
import "./chunk-D5NCJWRM.js";
import "./chunk-2S6N7PRS.js";
import "./chunk-7DHJRVJV.js";
import "./chunk-4JLAEOKH.js";
import "./chunk-JCK2OIYT.js";
import "./chunk-VFW7PX74.js";
import "./chunk-KKWATYV7.js";
import "./chunk-CTUJN5VU.js";
import "./chunk-LKDWXENB.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
//# sourceMappingURL=@angular_fire_compat_auth.js.map
