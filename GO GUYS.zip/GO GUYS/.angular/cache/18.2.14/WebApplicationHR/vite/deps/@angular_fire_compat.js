import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-U5B2F46F.js";
import "./chunk-3KOMAZYR.js";
import "./chunk-OE7PEGOX.js";
import "./chunk-P4UHYYRR.js";
import "./chunk-YSN7JSTZ.js";
import "./chunk-IGY35UNU.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-35ENWJA4.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
