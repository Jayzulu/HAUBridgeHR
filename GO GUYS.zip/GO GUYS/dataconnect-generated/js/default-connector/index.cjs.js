const { , validateArgs } = require('firebase/data-connect');

const connectorConfig = {
  connector: 'default',
  service: 'backup-thesis',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;

